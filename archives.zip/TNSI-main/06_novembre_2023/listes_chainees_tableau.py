t1 = [3, None]
t2 = [6,[7, None]]

print(t1)
print(t2)
      
t2[1][0] = 1

print(t1)
print(t2)

