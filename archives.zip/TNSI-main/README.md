# Ny-Harena RAKOTOVAO T3

# TNSI
## Chapitres par dates
### 02 octobre -> 02 octobre : Chapitre 3 , Structures de données - Programmation objet
### 03 octobre -> 13 octobre : Chapitre 4 , Bases de données - Bases de données relationnelles
### 6 novembre -> 7 novembre : Chapitre 5 , Structures de données - Type abstrait LISTE


_______________________________________________________________________________________________

## Autre
### 17 octobre -> DS Programmation Objet (Partie Pratique)
### 16 octobre -> 20 octobre : Projet : Animation avec tkinter
